from telebot import TeleBot

bot = TeleBot("token")  # ← Bot1 tokenını buraya yaz

@bot.message_handler(commands=["start"])
def start(message):
    bot.reply_to(message, "👋 Seksiyim! Ben Bot1'im.")

bot.infinity_polling()