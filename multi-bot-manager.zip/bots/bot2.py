from telebot import TeleBot

bot = TeleBot("token")  # ← Bot2 tokenını buraya yaz

@bot.message_handler(commands=["start"])
def start(message):
    bot.reply_to(message, "👋 Selam! Ben Bot2'yim.")

bot.infinity_polling()