#!/usr/bin/env python3
"""
🤖 Modern Telegram Bot Manager
Premium bot yönetim sistemi - v2.0
"""

import telebot
import subprocess
import json
import os
import logging
import time
import asyncio
from datetime import datetime, timedelta
from typing import Dict, Optional, List, Tuple
from dataclasses import dataclass, asdict
from pathlib import Path
import psutil
import threading
from contextlib import contextmanager
import yaml

# ====== KONFIGÜRASYON ======
@dataclass
class Config:
    bot_token: str = "token gir"
    admin_id: int = 7572889292
    config_file: str = "config.yaml"
    bots_dir: str = "bots"
    logs_dir: str = "logs"
    max_log_size: int = 10 * 1024 * 1024  # 10MB
    health_check_interval: int = 30  # saniye
    auto_restart: bool = True

@dataclass
class BotInfo:
    name: str
    file: str
    status: str = "stopped"
    pid: Optional[int] = None
    started_at: Optional[str] = None
    stopped_at: Optional[str] = None
    added_date: str = ""
    restart_count: int = 0
    cpu_usage: float = 0.0
    memory_mb: float = 0.0
    uptime: str = "00:00:00"

# ====== MODERN LOGGING SISTEMI ======
class ColoredFormatter(logging.Formatter):
    """Renkli log formatter"""
    
    COLORS = {
        'DEBUG': '\033[36m',     # Cyan
        'INFO': '\033[32m',      # Green
        'WARNING': '\033[33m',   # Yellow
        'ERROR': '\033[31m',     # Red
        'CRITICAL': '\033[35m',  # Magenta
    }
    RESET = '\033[0m'
    
    def format(self, record):
        log_color = self.COLORS.get(record.levelname, self.RESET)
        record.levelname = f"{log_color}{record.levelname}{self.RESET}"
        return super().format(record)

def setup_logging(config: Config) -> logging.Logger:
    """Modern logging sistemini ayarla"""
    os.makedirs(config.logs_dir, exist_ok=True)
    
    logger = logging.getLogger("BotManager")
    logger.setLevel(logging.INFO)
    
    # Console handler (renkli)
    console_handler = logging.StreamHandler()
    console_formatter = ColoredFormatter(
        fmt='%(asctime)s | %(levelname)s | %(message)s',
        datefmt='%H:%M:%S'
    )
    console_handler.setFormatter(console_formatter)
    
    # File handler
    file_handler = logging.FileHandler(
        Path(config.logs_dir) / "bot_manager.log",
        encoding='utf-8'
    )
    file_formatter = logging.Formatter(
        fmt='%(asctime)s | %(levelname)s | %(name)s | %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    file_handler.setFormatter(file_formatter)
    
    logger.addHandler(console_handler)
    logger.addHandler(file_handler)
    
    return logger

# ====== UTILITY FUNCTIONS ======
class Utils:
    @staticmethod
    def format_uptime(start_time: str) -> str:
        """Uptime'ı formatla"""
        try:
            start = datetime.fromisoformat(start_time.replace('Z', '+00:00'))
            delta = datetime.now() - start.replace(tzinfo=None)
            hours, remainder = divmod(int(delta.total_seconds()), 3600)
            minutes, seconds = divmod(remainder, 60)
            return f"{hours:02d}:{minutes:02d}:{seconds:02d}"
        except:
            return "00:00:00"
    
    @staticmethod
    def format_bytes(bytes_value: float) -> str:
        """Byte'ları okunabilir formata çevir"""
        for unit in ['B', 'KB', 'MB', 'GB']:
            if bytes_value < 1024.0:
                return f"{bytes_value:.1f}{unit}"
            bytes_value /= 1024.0
        return f"{bytes_value:.1f}TB"
    
    @staticmethod
    def create_progress_bar(percentage: float, length: int = 10) -> str:
        """Progress bar oluştur"""
        filled = int(length * percentage / 100)
        bar = "█" * filled + "░" * (length - filled)
        return f"[{bar}] {percentage:.1f}%"

# ====== MODERN BOT MANAGER ======
class ModernBotManager:
    def __init__(self, config: Config):
        self.config = config
        self.logger = setup_logging(config)
        self.bot = telebot.TeleBot(config.bot_token, threaded=True)
        self.bot_processes: Dict[str, subprocess.Popen] = {}
        self.bots_info: Dict[str, BotInfo] = {}
        self.monitoring_active = True
        
        self._setup_directories()
        self._load_config()
        self._setup_handlers()
        self._start_monitoring()
        
        self.logger.info("🚀 Modern Bot Manager başlatıldı!")

    def _setup_directories(self):
        """Gerekli klasörleri oluştur"""
        for directory in [self.config.bots_dir, self.config.logs_dir]:
            Path(directory).mkdir(exist_ok=True)

    def _load_config(self):
        """Konfigürasyonu yükle"""
        config_path = Path(self.config.config_file)
        if config_path.exists():
            try:
                with open(config_path, 'r', encoding='utf-8') as f:
                    data = yaml.safe_load(f) or {}
                    for name, bot_data in data.get('bots', {}).items():
                        self.bots_info[name] = BotInfo(**bot_data)
                self.logger.info(f"📁 Konfigürasyon yüklendi: {len(self.bots_info)} bot")
            except Exception as e:
                self.logger.error(f"❌ Config yükleme hatası: {e}")
        else:
            self._save_config()
            self.logger.info("📁 Yeni konfigürasyon dosyası oluşturuldu")

    def _save_config(self):
        """Konfigürasyonu kaydet"""
        try:
            data = {
                'bots': {name: asdict(info) for name, info in self.bots_info.items()},
                'settings': {
                    'auto_restart': self.config.auto_restart,
                    'health_check_interval': self.config.health_check_interval
                }
            }
            with open(self.config.config_file, 'w', encoding='utf-8') as f:
                yaml.dump(data, f, default_flow_style=False, allow_unicode=True)
        except Exception as e:
            self.logger.error(f"❌ Config kaydetme hatası: {e}")

    def _start_monitoring(self):
        """Bot monitoring sistemini başlat"""
        def monitor():
            while self.monitoring_active:
                self._update_bot_stats()
                self._check_bot_health()
                time.sleep(self.config.health_check_interval)
        
        monitoring_thread = threading.Thread(target=monitor, daemon=True)
        monitoring_thread.start()
        self.logger.info("🔍 Monitoring sistemi başlatıldı")

    def _update_bot_stats(self):
        """Bot istatistiklerini güncelle"""
        for name, process in self.bot_processes.items():
            if process.poll() is None:  # Process aktif
                try:
                    proc = psutil.Process(process.pid)
                    bot_info = self.bots_info[name]
                    bot_info.cpu_usage = proc.cpu_percent()
                    bot_info.memory_mb = proc.memory_info().rss / 1024 / 1024
                    bot_info.uptime = Utils.format_uptime(bot_info.started_at or "")
                except:
                    pass

    def _check_bot_health(self):
        """Bot sağlık kontrolü"""
        for name, process in list(self.bot_processes.items()):
            if process.poll() is not None:  # Process öldü
                self.logger.warning(f"⚠️ {name} botu beklenmedik şekilde durdu")
                self.bots_info[name].status = "crashed"
                self.bot_processes.pop(name)
                
                if self.config.auto_restart:
                    self.logger.info(f"🔄 {name} otomatik yeniden başlatılıyor...")
                    self._start_bot_internal(name)

    def _is_admin(self, user_id: int) -> bool:
        """Admin kontrolü"""
        return user_id == self.config.admin_id

    def _start_bot_internal(self, bot_name: str) -> bool:
        """Bot başlatma internal fonksiyonu"""
        try:
            bot_info = self.bots_info[bot_name]
            file_path = Path(self.config.bots_dir) / bot_info.file
            
            if not file_path.exists():
                self.logger.error(f"❌ Bot dosyası bulunamadı: {file_path}")
                return False
            
            # Log dosyası oluştur
            log_file = Path(self.config.logs_dir) / f"{bot_name}.log"
            
            with open(log_file, 'a', encoding='utf-8') as log:
                process = subprocess.Popen(
                    ["python", str(file_path)],
                    stdout=log,
                    stderr=subprocess.STDOUT,
                    text=True
                )
            
            self.bot_processes[bot_name] = process
            bot_info.status = "running"
            bot_info.pid = process.pid
            bot_info.started_at = datetime.now().isoformat()
            bot_info.restart_count += 1
            
            self._save_config()
            self.logger.info(f"✅ {bot_name} başlatıldı (PID: {process.pid})")
            return True
            
        except Exception as e:
            self.logger.error(f"❌ {bot_name} başlatma hatası: {e}")
            return False

    def _setup_handlers(self):
        """Bot handler'larını ayarla"""
        
        @self.bot.message_handler(commands=["start", "help"])
        def send_welcome(message):
            if not self._is_admin(message.from_user.id):
                self.bot.reply_to(message, "🚫 Bu bot yalnızca yönetici tarafından kullanılabilir.")
                return
            
            help_text = """
╭─────────────────────────────╮
│     🤖 **BOT MANAGER 2.0**     │
╰─────────────────────────────╯

🎛️ **Ana Komutlar:**
┣ `/dashboard` - Detaylı kontrol paneli
┣ `/botlar` - Bot listesi ve durumları
┣ `/stats` - Sistem istatistikleri

⚡ **Bot Kontrolü:**
┣ `/başlat <bot>` - Bot başlat
┣ `/durdur <bot>` - Bot durdur  
┣ `/restart <bot>` - Bot yeniden başlat
┣ `/kill <bot>` - Bot'u zorla durdur

🔧 **Yönetim:**
┣ `/ekle <bot> <dosya>` - Yeni bot ekle
┣ `/sil <bot>` - Bot'u sistemden kaldır
┣ `/loglar <bot>` - Bot loglarını görüntüle

📊 **İzleme:**
┣ `/monitor` - Canlı monitoring
┗ `/health` - Sistem sağlık raporu

💡 **Örnek:** `/başlat MyBot`
            """
            self.bot.reply_to(message, help_text, parse_mode='Markdown')

        @self.bot.message_handler(commands=["dashboard"])
        def show_dashboard(message):
            if not self._is_admin(message.from_user.id):
                return
            
            total_bots = len(self.bots_info)
            running_bots = sum(1 for info in self.bots_info.values() if info.status == "running")
            total_memory = sum(info.memory_mb for info in self.bots_info.values())
            
            system_memory = psutil.virtual_memory()
            system_cpu = psutil.cpu_percent(interval=1)
            
            dashboard = f"""
╭──────────────────────────────╮
│        📊 **DASHBOARD**         │
╰──────────────────────────────╯

🤖 **Bot Durumu:**
┣ Toplam Bot: `{total_bots}`
┣ Aktif Bot: `{running_bots}`
┗ Toplam Bellek: `{total_memory:.1f}MB`

💻 **Sistem Durumu:**
┣ CPU: `{Utils.create_progress_bar(system_cpu)}`
┣ RAM: `{Utils.create_progress_bar(system_memory.percent)}`
┗ Uptime: `{Utils.format_uptime(datetime.now().isoformat())}`

🔄 **Son Güncelleme:** `{datetime.now().strftime('%H:%M:%S')}`
            """
            
            self.bot.reply_to(message, dashboard, parse_mode='Markdown')

        @self.bot.message_handler(commands=["botlar"])
        def list_bots(message):
            if not self._is_admin(message.from_user.id):
                return
            
            if not self.bots_info:
                self.bot.reply_to(message, "📭 Henüz hiç bot eklenmemiş.\n\n💡 `/ekle <bot_adı> <dosya.py>` ile bot ekleyebilirsiniz.")
                return

            msg = "╭──────────────────────────────╮\n"
            msg += "│         🤖 **BOT LİSTESİ**        │\n"
            msg += "╰──────────────────────────────╯\n\n"
            
            for name, info in self.bots_info.items():
                status_emoji = {
                    "running": "🟢",
                    "stopped": "🔴", 
                    "crashed": "🟡"
                }.get(info.status, "⚪")
                
                msg += f"{status_emoji} **{name}**\n"
                msg += f"┣ 📄 Dosya: `{info.file}`\n"
                
                if info.status == "running":
                    msg += f"┣ 🔧 PID: `{info.pid}`\n"
                    msg += f"┣ ⏱️ Uptime: `{info.uptime}`\n"
                    msg += f"┣ 💾 RAM: `{info.memory_mb:.1f}MB`\n"
                    msg += f"┣ 🔄 CPU: `{info.cpu_usage:.1f}%`\n"
                
                msg += f"┗ 📅 Eklendi: `{info.added_date}`\n\n"
            
            self.bot.reply_to(message, msg, parse_mode='Markdown')

        @self.bot.message_handler(commands=["başlat"])
        def start_bot(message):
            if not self._is_admin(message.from_user.id):
                return
            
            parts = message.text.split()
            if len(parts) != 2:
                self.bot.reply_to(message, "❌ **Kullanım:** `/başlat <bot_adı>`", parse_mode='Markdown')
                return
            
            bot_name = parts[1]
            
            if bot_name not in self.bots_info:
                self.bot.reply_to(message, f"❌ `{bot_name}` isimli bot bulunamadı!", parse_mode='Markdown')
                return
            
            if self.bots_info[bot_name].status == "running":
                self.bot.reply_to(message, f"⚡ `{bot_name}` zaten çalışıyor!", parse_mode='Markdown')
                return
            
            # Loading animasyonu
            loading_msg = self.bot.reply_to(message, "🔄 Bot başlatılıyor...")
            
            if self._start_bot_internal(bot_name):
                self.bot.edit_message_text(
                    f"🚀 **{bot_name}** başarıyla başlatıldı!\n\n"
                    f"┣ 🔧 PID: `{self.bots_info[bot_name].pid}`\n"
                    f"┗ 📊 `/botlar` ile durumu görüntüleyebilirsiniz.",
                    loading_msg.chat.id,
                    loading_msg.message_id,
                    parse_mode='Markdown'
                )
            else:
                self.bot.edit_message_text(
                    f"❌ **{bot_name}** başlatılamadı!\n\n"
                    f"💡 `/loglar {bot_name}` ile detayları inceleyebilirsiniz.",
                    loading_msg.chat.id,
                    loading_msg.message_id,
                    parse_mode='Markdown'
                )

        @self.bot.message_handler(commands=["durdur"])
        def stop_bot(message):
            if not self._is_admin(message.from_user.id):
                return
                
            parts = message.text.split()
            if len(parts) != 2:
                self.bot.reply_to(message, "❌ **Kullanım:** `/durdur <bot_adı>`", parse_mode='Markdown')
                return
            
            bot_name = parts[1]
            
            if bot_name not in self.bots_info:
                self.bot.reply_to(message, f"❌ `{bot_name}` isimli bot bulunamadı!", parse_mode='Markdown')
                return
            
            if bot_name not in self.bot_processes:
                self.bot.reply_to(message, f"⛔ `{bot_name}` zaten durdurulmuş.", parse_mode='Markdown')
                return
            
            try:
                process = self.bot_processes[bot_name]
                process.terminate()
                process.wait(timeout=5)
                
                self.bot_processes.pop(bot_name)
                self.bots_info[bot_name].status = "stopped"
                self.bots_info[bot_name].stopped_at = datetime.now().isoformat()
                self._save_config()
                
                self.bot.reply_to(message, f"⛔ **{bot_name}** başarıyla durduruldu!", parse_mode='Markdown')
                self.logger.info(f"Bot durduruldu: {bot_name}")
                
            except subprocess.TimeoutExpired:
                process.kill()
                self.bot.reply_to(message, f"💀 **{bot_name}** zorla durduruldu!", parse_mode='Markdown')
            except Exception as e:
                self.bot.reply_to(message, f"❌ Hata: `{str(e)}`", parse_mode='Markdown')

        @self.bot.message_handler(commands=["restart"])
        def restart_bot(message):
            if not self._is_admin(message.from_user.id):
                return
                
            parts = message.text.split()
            if len(parts) != 2:
                self.bot.reply_to(message, "❌ **Kullanım:** `/restart <bot_adı>`", parse_mode='Markdown')
                return
            
            bot_name = parts[1]
            
            if bot_name not in self.bots_info:
                self.bot.reply_to(message, f"❌ `{bot_name}` isimli bot bulunamadı!", parse_mode='Markdown')
                return
            
            loading_msg = self.bot.reply_to(message, "🔄 Bot yeniden başlatılıyor...")
            
            # Önce durdur
            if bot_name in self.bot_processes:
                try:
                    self.bot_processes[bot_name].terminate()
                    self.bot_processes[bot_name].wait(timeout=5)
                    self.bot_processes.pop(bot_name)
                except:
                    pass
            
            time.sleep(2)  # Kısa bekleme
            
            # Sonra başlat
            if self._start_bot_internal(bot_name):
                self.bot.edit_message_text(
                    f"🔄 **{bot_name}** yeniden başlatıldı!\n\n"
                    f"┣ 🔧 PID: `{self.bots_info[bot_name].pid}`\n"
                    f"┗ 🔢 Restart Sayısı: `{self.bots_info[bot_name].restart_count}`",
                    loading_msg.chat.id,
                    loading_msg.message_id,
                    parse_mode='Markdown'
                )
            else:
                self.bot.edit_message_text(
                    f"❌ **{bot_name}** yeniden başlatılamadı!",
                    loading_msg.chat.id,
                    loading_msg.message_id,
                    parse_mode='Markdown'
                )

        @self.bot.message_handler(commands=["ekle"])
        def add_bot(message):
            if not self._is_admin(message.from_user.id):
                return
                
            parts = message.text.split()
            if len(parts) != 3:
                self.bot.reply_to(message, "❌ **Kullanım:** `/ekle <bot_adı> <dosya.py>`", parse_mode='Markdown')
                return
            
            bot_name, file_name = parts[1], parts[2]
            
            if bot_name in self.bots_info:
                self.bot.reply_to(message, f"❌ `{bot_name}` zaten mevcut!", parse_mode='Markdown')
                return
            
            file_path = Path(self.config.bots_dir) / file_name
            if not file_path.exists():
                self.bot.reply_to(message, f"❌ Dosya bulunamadı: `{file_path}`", parse_mode='Markdown')
                return
            
            self.bots_info[bot_name] = BotInfo(
                name=bot_name,
                file=file_name,
                added_date=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            )
            self._save_config()
            
            self.bot.reply_to(message, 
                f"✅ **{bot_name}** başarıyla eklendi!\n\n"
                f"┣ 📄 Dosya: `{file_name}`\n"
                f"┗ 🚀 `/başlat {bot_name}` ile başlatabilirsiniz.",
                parse_mode='Markdown'
            )
            self.logger.info(f"Yeni bot eklendi: {bot_name}")

        @self.bot.message_handler(commands=["monitor"])
        def show_monitor(message):
            if not self._is_admin(message.from_user.id):
                return
            
            running_bots = [name for name, info in self.bots_info.items() if info.status == "running"]
            
            if not running_bots:
                self.bot.reply_to(message, "📊 Şu anda çalışan bot yok.")
                return
            
            monitor_msg = "╭──────────────────────────────╮\n"
            monitor_msg += "│       📊 **CANLI İZLEME**       │\n"
            monitor_msg += "╰──────────────────────────────╯\n\n"
            
            for bot_name in running_bots:
                info = self.bots_info[bot_name]
                monitor_msg += f"🟢 **{bot_name}**\n"
                monitor_msg += f"┣ CPU: {Utils.create_progress_bar(info.cpu_usage, 8)}\n"
                monitor_msg += f"┣ RAM: `{info.memory_mb:.1f}MB`\n"
                monitor_msg += f"┗ Uptime: `{info.uptime}`\n\n"
            
            self.bot.reply_to(message, monitor_msg, parse_mode='Markdown')

    def run(self):
        """Bot'u çalıştır"""
        try:
            print("\n" + "="*60)
            print("🚀 MODERN BOT MANAGER BAŞLATILIYOR")
            print("="*60)
            print(f"📊 Toplam Bot: {len(self.bots_info)}")
            print(f"🔍 Monitoring: {'✅ Aktif' if self.monitoring_active else '❌ Pasif'}")
            print(f"⚙️  Auto Restart: {'✅ Aktif' if self.config.auto_restart else '❌ Pasif'}")
            print("="*60)
            
            self.logger.info("🎯 Bot polling başlatılıyor...")
            self.bot.infinity_polling(timeout=10, long_polling_timeout=5)
            
        except Exception as e:
            self.logger.error(f"❌ Bot çalıştırma hatası: {e}")
        finally:
            self.monitoring_active = False
            # Temizlik işlemleri
            for name, process in self.bot_processes.items():
                try:
                    process.terminate()
                    self.logger.info(f"🧹 {name} botu temizlendi")
                except:
                    pass

# ====== MAIN ======
if __name__ == "__main__":
    try:
        config = Config()
        manager = ModernBotManager(config)
        manager.run()
    except KeyboardInterrupt:
        print("\n" + "="*50)
        print("👋 Bot Manager güvenli şekilde kapatılıyor...")
        print("="*50)
    except Exception as e:
        print(f"❌ Kritik hata: {e}")
        logging.error(f"Kritik hata: {e}")